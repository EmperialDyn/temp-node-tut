const url = 'https://course-api.com/react-tabs-project';

const App = () => {
  return <h2>Tabs Starter</h2>;
};
export default App;
