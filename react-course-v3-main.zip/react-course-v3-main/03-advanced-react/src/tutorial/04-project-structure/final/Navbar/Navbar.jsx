import './Navbar.css';
const Navbar = () => {
  return (
    <div className='navbar'>
      <h2>navbar component</h2>
    </div>
  );
};
export default Navbar;
