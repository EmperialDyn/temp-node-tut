import { useEffect, useState } from 'react';

const MultipleReturnsBasics = () => {
  return <h2>Multiple Returns Basics</h2>;
};
export default MultipleReturnsBasics;
